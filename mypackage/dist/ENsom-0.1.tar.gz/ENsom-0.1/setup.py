from setuptools import setup
setup(name="ENsom",
version="0.1",
description="This is code",
long_description="This is long code",
author="shivam",
packages=['ENsom'],
install_requires=[])
